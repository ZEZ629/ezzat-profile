import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

import useTranslation from "../../locales/useTranslation";
import "./Services.css";

gsap.registerPlugin(ScrollTrigger);

function Services() {
  const t = useTranslation();

  const sectionRef = useRef(null);
  const trackRef = useRef(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const track = trackRef.current;

    if (!section || !track) return;

    if (window.innerWidth <= 600) return;

    const ctx = gsap.context(() => {
      const cards = track.querySelectorAll(".service-card");

      if (!cards.length) return;

      const isRTL =
        document.documentElement.dir === "rtl";

      const getCardWidth = () =>
        cards[0].getBoundingClientRect().width;

      const getGap = () => {
        const styles = window.getComputedStyle(track);
        return parseFloat(styles.columnGap) || 0;
      };

      const getStartX = () => {
        const cardWidth = getCardWidth();

        return (
          (window.innerWidth - cardWidth) / 2
        );
      };

      const getStep = () =>
        getCardWidth() + getGap();

      const getTotalDistance = () =>
        getStep() * (cards.length - 1);

      /*
       * 01 starts centered.
       * On every snapped scroll step, the next card
       * is revealed beside the previous cards.
       */
      gsap.set(track, {
        x: getStartX(),
      });

      gsap.to(track, {
        x: () => {
          const startX = getStartX();
          const distance = getTotalDistance();

          return isRTL
            ? startX + distance
            : startX - distance;
        },

        ease: "none",

        scrollTrigger: {
          trigger: section,

          start: "top top",

          /*
           * The section itself provides the scroll space.
           * No pin is used here, so the page cannot jump upward.
           */
          end: "bottom top",

          scrub: 0.7,

          snap: {
            snapTo: (value) => {
              const steps = cards.length - 1;

              if (steps <= 0) return 0;

              return (
                Math.round(value * steps) /
                steps
              );
            },

            duration: {
              min: 0.2,
              max: 0.45,
            },

            delay: 0.02,

            ease: "power2.out",
          },

          invalidateOnRefresh: true,
        },
      });
    }, section);

    const handleResize = () => {
      ScrollTrigger.refresh();
    };

    window.addEventListener(
      "resize",
      handleResize
    );

    return () => {
      window.removeEventListener(
        "resize",
        handleResize
      );

      ctx.revert();
    };
  }, [t.services.items.length]);

  return (
    <section
      className="services"
      id="services"
      ref={sectionRef}
    >
      <div className="services-sticky">
        <div className="services-header">
          <p className="services-label">
            {t.services.label}
          </p>

          <h2>
            {t.services.title}
          </h2>

          <p className="services-description">
            {t.services.description}
          </p>
        </div>

        <div className="services-viewport">
          <div
            className="services-track"
            ref={trackRef}
          >
            {t.services.items.map((service) => (
              <article
                className="service-card"
                key={service.number}
              >
                <span className="service-number">
                  {service.number}
                </span>

                <div className="service-card-content">
                  <span className="service-index">
                    {t.services.indexLabel}
                  </span>

                  <h3>
                    {service.title}
                  </h3>

                  <p>
                    {service.description}
                  </p>
                </div>

                <div className="service-card-arrow">
                  {document.documentElement.dir ===
                  "rtl"
                    ? "←"
                    : "→"}
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="services-scroll-hint">
          <span>
            {t.services.scrollHint}
          </span>

          <i />
        </div>
      </div>
    </section>
  );
}

export default Services;
